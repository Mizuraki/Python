TOKEN = '1402656916:AAF-tcgBKx-dC-QnNN6OhVejpEH3VLvGUVc'

keys = {
    'доллар': 'USD',
    'Доллар': 'USD',
    'евро': 'EUR',
    'Евро': 'EUR',
    'рубль': 'RUB',
    'Рубль': 'RUB',
}